-- =====================================================
-- VEL TECH BUS MANAGEMENT SYSTEM - FIXED DATABASE SCHEMA
-- =====================================================
-- This version removes "if not exists" clauses that cause syntax errors
-- and includes DROP statements to handle existing policies

-- 1. STUDENT LOGINS TABLE
-- =====================================================
create table if not exists public.student_logins (
  id bigint generated always as identity primary key,
  email text not null,
  student_id text not null check (student_id ~ '^[0-9]{5}$'),
  login_at timestamptz not null default now()
);

-- Enable Row Level Security
alter table public.student_logins enable row level security;

-- Drop existing policies if they exist (to avoid conflicts)
drop policy if exists "allow_insert_from_anon" on public.student_logins;
drop policy if exists "allow_select_from_anon" on public.student_logins;
drop policy if exists "allow_delete_from_anon" on public.student_logins;

-- Create policies for student_logins
create policy "allow_insert_from_anon"
on public.student_logins
for insert
to anon
with check (true);

create policy "allow_select_from_anon"
on public.student_logins
for select
to anon
using (true);

create policy "allow_delete_from_anon"
on public.student_logins
for delete
to anon
using (true);

-- 2. ADMIN CREDENTIALS TABLE
-- =====================================================
create table if not exists public.admin_credentials (
  id bigint generated always as identity primary key,
  username text not null unique,
  password text not null,
  phone text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Enable Row Level Security for admin credentials
alter table public.admin_credentials enable row level security;

-- Drop existing policies if they exist
drop policy if exists "allow_select_admin_credentials_from_anon" on public.admin_credentials;
drop policy if exists "allow_insert_admin_credentials_from_anon" on public.admin_credentials;
drop policy if exists "allow_update_admin_credentials_from_anon" on public.admin_credentials;

-- Create policies for admin_credentials
create policy "allow_select_admin_credentials_from_anon"
on public.admin_credentials
for select
to anon
using (true);

create policy "allow_insert_admin_credentials_from_anon"
on public.admin_credentials
for insert
to anon
with check (true);

create policy "allow_update_admin_credentials_from_anon"
on public.admin_credentials
for update
to anon
using (true)
with check (true);

-- 3. BUS ROUTES TABLE
-- =====================================================
create table if not exists public.bus_routes (
  id bigint generated always as identity primary key,
  route_number text not null unique,
  route_name text not null,
  description text,
  start_location text not null,
  end_location text not null,
  total_distance_km decimal(5,2),
  estimated_duration_minutes integer,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Enable Row Level Security
alter table public.bus_routes enable row level security;

-- Drop existing policies if they exist
drop policy if exists "allow_select_routes_from_anon" on public.bus_routes;
drop policy if exists "allow_insert_routes_from_anon" on public.bus_routes;
drop policy if exists "allow_update_routes_from_anon" on public.bus_routes;
drop policy if exists "allow_delete_routes_from_anon" on public.bus_routes;

-- Create policies for bus_routes
create policy "allow_select_routes_from_anon"
on public.bus_routes
for select
to anon
using (true);

create policy "allow_insert_routes_from_anon"
on public.bus_routes
for insert
to anon
with check (true);

create policy "allow_update_routes_from_anon"
on public.bus_routes
for update
to anon
using (true)
with check (true);

create policy "allow_delete_routes_from_anon"
on public.bus_routes
for delete
to anon
using (true);

-- 4. BUS STOPS TABLE
-- =====================================================
create table if not exists public.bus_stops (
  id bigint generated always as identity primary key,
  stop_code text not null unique,
  stop_name text not null,
  address text,
  latitude decimal(10, 8),
  longitude decimal(11, 8),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Enable Row Level Security
alter table public.bus_stops enable row level security;

-- Drop existing policies if they exist
drop policy if exists "allow_select_stops_from_anon" on public.bus_stops;
drop policy if exists "allow_insert_stops_from_anon" on public.bus_stops;
drop policy if exists "allow_update_stops_from_anon" on public.bus_stops;
drop policy if exists "allow_delete_stops_from_anon" on public.bus_stops;

-- Create policies for bus_stops
create policy "allow_select_stops_from_anon"
on public.bus_stops
for select
to anon
using (true);

create policy "allow_insert_stops_from_anon"
on public.bus_stops
for insert
to anon
with check (true);

create policy "allow_update_stops_from_anon"
on public.bus_stops
for update
to anon
using (true)
with check (true);

create policy "allow_delete_stops_from_anon"
on public.bus_stops
for delete
to anon
using (true);

-- 5. ROUTE STOPS MAPPING TABLE (Many-to-Many relationship)
-- =====================================================
create table if not exists public.route_stops (
  id bigint generated always as identity primary key,
  route_id bigint not null references public.bus_routes(id) on delete cascade,
  stop_id bigint not null references public.bus_stops(id) on delete cascade,
  sequence_order integer not null,
  estimated_arrival_time time,
  is_pickup_point boolean not null default true,
  is_drop_point boolean not null default true,
  created_at timestamptz not null default now(),
  unique(route_id, stop_id),
  unique(route_id, sequence_order)
);

-- Enable Row Level Security
alter table public.route_stops enable row level security;

-- Drop existing policies if they exist
drop policy if exists "allow_select_route_stops_from_anon" on public.route_stops;
drop policy if exists "allow_insert_route_stops_from_anon" on public.route_stops;
drop policy if exists "allow_update_route_stops_from_anon" on public.route_stops;
drop policy if exists "allow_delete_route_stops_from_anon" on public.route_stops;

-- Create policies for route_stops
create policy "allow_select_route_stops_from_anon"
on public.route_stops
for select
to anon
using (true);

create policy "allow_insert_route_stops_from_anon"
on public.route_stops
for insert
to anon
with check (true);

create policy "allow_update_route_stops_from_anon"
on public.route_stops
for update
to anon
using (true)
with check (true);

create policy "allow_delete_route_stops_from_anon"
on public.route_stops
for delete
to anon
using (true);

-- 6. ADMIN NOTES TABLE
-- =====================================================
create table if not exists public.admin_notes (
  id bigint generated always as identity primary key,
  title text not null,
  content text not null,
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high', 'urgent')),
  category text,
  is_important boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Enable Row Level Security
alter table public.admin_notes enable row level security;

-- Drop existing policies if they exist
drop policy if exists "allow_select_notes_from_anon" on public.admin_notes;
drop policy if exists "allow_insert_notes_from_anon" on public.admin_notes;
drop policy if exists "allow_update_notes_from_anon" on public.admin_notes;
drop policy if exists "allow_delete_notes_from_anon" on public.admin_notes;

-- Create policies for admin_notes
create policy "allow_select_notes_from_anon"
on public.admin_notes
for select
to anon
using (true);

create policy "allow_insert_notes_from_anon"
on public.admin_notes
for insert
to anon
with check (true);

create policy "allow_update_notes_from_anon"
on public.admin_notes
for update
to anon
using (true)
with check (true);

create policy "allow_delete_notes_from_anon"
on public.admin_notes
for delete
to anon
using (true);

-- 7. UTILITY FUNCTIONS AND TRIGGERS
-- =====================================================

-- Function to update updated_at timestamp
create or replace function update_updated_at_column()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- Drop existing triggers if they exist
drop trigger if exists update_admin_credentials_updated_at on public.admin_credentials;
drop trigger if exists update_bus_routes_updated_at on public.bus_routes;
drop trigger if exists update_bus_stops_updated_at on public.bus_stops;
drop trigger if exists update_admin_notes_updated_at on public.admin_notes;

-- Create triggers for updated_at columns
create trigger update_admin_credentials_updated_at
before update on public.admin_credentials
for each row
execute function update_updated_at_column();

create trigger update_bus_routes_updated_at
before update on public.bus_routes
for each row
execute function update_updated_at_column();

create trigger update_bus_stops_updated_at
before update on public.bus_stops
for each row
execute function update_updated_at_column();

create trigger update_admin_notes_updated_at
before update on public.admin_notes
for each row
execute function update_updated_at_column();

-- 8. SAMPLE DATA INSERTION
-- =====================================================

-- Insert default admin credentials
insert into public.admin_credentials (username, password, phone)
values ('admin', 'admin', '+917207509620')
on conflict (username) do nothing;

-- Insert sample bus routes
insert into public.bus_routes (route_number, route_name, description, start_location, end_location, total_distance_km, estimated_duration_minutes)
values 
  ('R001', 'Campus to City Center', 'Main route connecting campus to downtown', 'Vel Tech University', 'City Center', 15.5, 45),
  ('R002', 'Campus to Railway Station', 'Direct route to railway station', 'Vel Tech University', 'Central Railway Station', 12.0, 35),
  ('R003', 'Campus to Airport', 'Express route to airport', 'Vel Tech University', 'International Airport', 25.0, 60)
on conflict (route_number) do nothing;

-- Insert sample bus stops
insert into public.bus_stops (stop_code, stop_name, address, latitude, longitude)
values 
  ('ST001', 'University Main Gate', 'Vel Tech University Main Entrance', 13.0827, 80.2707),
  ('ST002', 'City Center Mall', 'Downtown Shopping District', 13.0839, 80.2700),
  ('ST003', 'Railway Station', 'Central Railway Station Platform 1', 13.0845, 80.2695),
  ('ST004', 'Airport Terminal', 'International Airport Terminal 1', 13.0850, 80.2690),
  ('ST005', 'Tech Park', 'IT Technology Park', 13.0820, 80.2710)
on conflict (stop_code) do nothing;

-- Insert sample route-stop mappings
insert into public.route_stops (route_id, stop_id, sequence_order, estimated_arrival_time, is_pickup_point, is_drop_point)
select 
  r.id as route_id,
  s.id as stop_id,
  case 
    when r.route_number = 'R001' and s.stop_code = 'ST001' then 1
    when r.route_number = 'R001' and s.stop_code = 'ST002' then 2
    when r.route_number = 'R002' and s.stop_code = 'ST001' then 1
    when r.route_number = 'R002' and s.stop_code = 'ST003' then 2
    when r.route_number = 'R003' and s.stop_code = 'ST001' then 1
    when r.route_number = 'R003' and s.stop_code = 'ST004' then 2
  end as sequence_order,
  case 
    when r.route_number = 'R001' and s.stop_code = 'ST001' then '08:00:00'::time
    when r.route_number = 'R001' and s.stop_code = 'ST002' then '08:45:00'::time
    when r.route_number = 'R002' and s.stop_code = 'ST001' then '09:00:00'::time
    when r.route_number = 'R002' and s.stop_code = 'ST003' then '09:35:00'::time
    when r.route_number = 'R003' and s.stop_code = 'ST001' then '10:00:00'::time
    when r.route_number = 'R003' and s.stop_code = 'ST004' then '11:00:00'::time
  end as estimated_arrival_time,
  true as is_pickup_point,
  true as is_drop_point
from public.bus_routes r
cross join public.bus_stops s
where (r.route_number, s.stop_code) in (
  ('R001', 'ST001'), ('R001', 'ST002'),
  ('R002', 'ST001'), ('R002', 'ST003'),
  ('R003', 'ST001'), ('R003', 'ST004')
)
on conflict (route_id, stop_id) do nothing;

-- Insert sample admin notes
insert into public.admin_notes (title, content, priority, category, is_important)
values 
  ('System Maintenance', 'Scheduled maintenance on Sunday 2 AM - 4 AM', 'medium', 'maintenance', false),
  ('Route R001 Update', 'Route R001 timing changed due to traffic conditions', 'high', 'route_update', true),
  ('New Bus Addition', 'Two new buses added to fleet - Bus #101 and #102', 'medium', 'fleet', false),
  ('Student Feedback', 'Students requesting additional stops on Route R002', 'low', 'feedback', false)
on conflict do nothing;

-- =====================================================
-- SETUP COMPLETE!
-- =====================================================
